Koridor remote control
Windows may say the publisher is unknown: the file has no paid certificate.
Right click the exe, Properties, tick Unblock, then Open.
If SmartScreen appears, choose More info, then Run anyway.
Put the bot server address in the window. Default is http://127.0.0.1:8080
